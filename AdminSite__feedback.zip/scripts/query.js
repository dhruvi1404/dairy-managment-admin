const accordion_query = document.querySelector("#main-accordion__query");

const addQuery = (id, doc) => {
  const template = `<div class = "card">
<div class="card-header" id="heading-${id}">
    <h5 class="mb-0 d-flex align-items-center justify-content-between">
        <button aria-controls="collapse${id}" aria-expanded="true" class="btn btn-primary" data-target="#collapse${id}" data-toggle="collapse" type="button">
            <i class="fas fa-user-circle">
            </i>
            ${doc.u_name}
        </button>
        <div class="date">
           ${dateFns.format(doc.time.toDate(), "Do MMM/YY")}
        </div>
       
         <div>
            <span data-toggle="tooltip" title="Delete Review"> <i class="far fas fa-trash ml-5 delete"></i></span>
         </div>
         
       
    </h5>
</div>
<div aria-labelledby="heading-${id}" class="collapse show" data-parent="#main-accordion__query" id="collapse${id}">
    <div class="card-body">
        <h5 class="">${doc.title}</h5>
        ${doc.description}
    </div>
</div>
</div>`;

  accordion_query.innerHTML += template;
};

//fetching data realtime from database
db.collection("queries")
  .orderBy("time", "desc")
  .onSnapshot(snapshot => {
    snapshot.docChanges().forEach(change => {
      const doc = change.doc;
      if (change.type === "added") {
        addQuery(doc.id, doc.data());
      } else if (change.type === "removed") {
        deleteRecord(doc.id);
      }
    });
  });

//triggering delete  review event from html
accordion_query.addEventListener("click", e => {
  if (e.target.classList.contains("delete")) {
      console.log(e.target.parentElement.parentElement.parentElement.parentElement);
    const id = e.target.parentElement.parentElement.parentElement.parentElement.getAttribute(
      "id"
    );
    db.collection("queries")
      .doc(id.slice(8))
      .delete()
      .then(() => {
        console.log("deleted feedback");
      });
  }
});
