const accordion_feedback = document.querySelector("#main-accordion__feedback");

const addCard = (id, doc) => {
  const template = `<div class = "card">
 <div class="card-header" id="heading-${id}">
     <h5 class="mb-0 d-flex align-items-center justify-content-between">
         <button aria-controls="collapse${id}" aria-expanded="true" class="btn btn-primary" data-target="#collapse${id}" data-toggle="collapse" type="button">
             <i class="fas fa-user-circle">
             </i>
             ${doc.user_name}
         </button>
         <div class="date">
            ${dateFns.format(doc.time.toDate(), "Do MMM/YY")}
         </div>
        
          <div class="rating">
              <span class="fa fa-star">
              </span>
              <span class="fa fa-star">
              </span>
              <span class="fa fa-star">
              </span>
              <span class="fa fa-star">
              </span>
              <span class="fa fa-star">
              </span>
             <span data-toggle="tooltip" title="Delete Review"> <i class="far fas fa-trash ml-5 delete"></i></span>
          </div>
          
        
     </h5>
 </div>
 <div aria-labelledby="heading-${id}" class="collapse show" data-parent="#main-accordion__feedback" id="collapse${id}">
     <div class="card-body">
         ${doc.review}
     </div>
 </div>
 </div>`;
  accordion_feedback.innerHTML += template;
  updateRating(id, Number.parseInt(doc.rating));
};

//method to update rating
const updateRating = (id, user_rat) => {
  const rating = document.querySelector(`#heading-${id} .rating`); //getting required rating container
  const stars = rating.children;
  Array.from(stars).reduce((acc, curr) => {
    if (acc <= user_rat) {
      curr.classList.add("checked");
      acc++;
    }
    return acc;
  }, 1);
};

//triggering delete  review event from html
accordion_feedback.addEventListener('click',e=>{
  if(e.target.classList.contains('delete'))
  {
   const id = e.target.parentElement.parentElement.parentElement.parentElement.getAttribute('id'); 
    db.collection('feedback').doc(id.slice(8)).delete().then(()=>{
      console.log("deleted feedback");
    });
  }
})

//method to delete review/query from DOM when change happen in database
const deleteRecord = id => {
  const cards = document.querySelectorAll(".card-header");
  cards.forEach(card => {
    if (card.getAttribute("id") === `heading-${id}`) {
      card.parentElement.remove();
    }
  });
};

//realtime updating data
db.collection("feedback")
  .orderBy("time", "desc")
  .onSnapshot(snapshot => {
    snapshot.docChanges().forEach(change => {
      const doc = change.doc;
      if (change.type === "added") {
        addCard(doc.id, doc.data());
        updateRating(doc.id, doc.data().rating);
      } else if (change.type === "removed") {
        deleteRecord(doc.id);
      }
    });
  });


