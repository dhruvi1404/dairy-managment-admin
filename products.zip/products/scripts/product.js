var options = {
  chart: {
    type: "bar",
  
  },
  series: [
    {
      name: "sales(in Ltr)",
      data: [30, 40, 35, 50, 75, 80]
    }
  ],
  xaxis: {
    categories: [
      "Amul Shakti",
      "Amul Gold",
      "Amul Taza",
      "Mahi",
      "Camel milk",
      "Goat milk"
    ]
  },
  title:{
    text:"Product wise sales",
    align:'center',
  }
};
var chart = new ApexCharts(document.querySelector("#chart1"), options);

chart.render();
var options = {
  chart: {
    type: "bar"
  },
  series: [
    {
      name: "sales-qty",
      data: [30, 40, 35, 50, 75, 80]
    }
  ],
  xaxis: {
    categories: [
      "Mehtas",
      "Champak dairy",
      "xyz dairy",
      "Ramji Doodhwale",
      "Shyamji Dairy",
      "Shambhu bharvad"
    ]
  },
  title:{
    text:"Shop/Vendor sales",
    align:'center',
  }
};
var chart = new ApexCharts(document.querySelector("#chart2"), options);

chart.render();
var options = {
  chart: {
    type: "bar"
  },
  series: [
    {
      name: "sales-qty",
      data: [300, 212, 150, 50]
    }
  ],
  xaxis: {
    categories: [
      "Amul",
      "Mahi",
      "Gokul",
      "Motherdairy"
    ]
  },
  title:{
    text:"Brandwise wise sales",
    align:'center',
  }
};
var chart = new ApexCharts(document.querySelector("#chart3"), options);

chart.render();
