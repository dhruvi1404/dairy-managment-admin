import 'package:flutter/material.dart';

class Subscription extends StatelessWidget {
 
static const routeSub='/subscription';
  @override
  Widget build(BuildContext context) {
    return Center(child:Text('subscription'));
  }
}