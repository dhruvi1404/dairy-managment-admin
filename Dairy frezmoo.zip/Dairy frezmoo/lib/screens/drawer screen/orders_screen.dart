import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_app/database/Model.dart';
import 'package:flutter_app/login.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:dio/dio.dart';
import 'package:shimmer/shimmer.dart';

bool _loading = false;
Map<String,String> imaged={};
class OrderScreen extends StatefulWidget {

  static const orderScreenRoute = '/orderRoute';

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<OrderScreen> {
  final dio = new Dio(); // for http requests
  Widget _appBarTitle = new Text('Search...');
  Icon _searchIcon = new Icon(Icons.search);

  Widget list(int id,int jd,String key) {
    return Container(
      padding: EdgeInsets.only(left: 15, right: 15, top: 10),
      child: Container(
        padding: EdgeInsets.all(0),
        height: 80,
        width: double.infinity,
        decoration: BoxDecoration(
            boxShadow: [
              BoxShadow(
                  color: Colors.grey, blurRadius: 10, offset: Offset(2, 2))
            ],
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Colors.white),
            color: Colors.white),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Expanded(
              child: Column(
                children: <Widget>[
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(left: 5.0, top: 10),
                      child: Container(
                          child: Text(
                        '${current.permUser.totalOrders[id].products[jd].productName} * ${current.permUser.totalOrders[id].quantities[jd]}',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 15.0,
                          fontFamily: 'JosefinSans',
                        ),
                      )),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(left: 10, top: 10, right: 110),
                    child: Text(
                      '${current.permUser.totalOrders[id].products[jd].price*current.permUser.totalOrders[id].quantities[jd]}\$',
                      style: TextStyle(fontSize: 15, fontFamily: 'JosefinSans'),
                    ),
                  )
                ],
              ),
            ),
            ClipRRect(
                borderRadius: BorderRadius.only(
                    topRight: Radius.circular(20),
                    bottomRight: Radius.circular(20)),
                child:imaged.containsKey(key) ?Image.network(imaged[key]):Image.asset(
                  'assets/images/logo.png',
                  fit: BoxFit.cover,
                  color: Colors.grey,
                )),
          ],
        ),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    // TODO: implement initState
    print("in init state");
    _loading = true;
    if(current.permUser.totalOrders.length==0)
    current.getAllOrders().then((val) {
      print("get all ${current.permUser.totalOrders.length}");
      _loading = false;
      imaged={};
      for(Order order in current.permUser.totalOrders)
        for(Product product in order.products)
           {
             current.getDownloadUrl(product.imageURL).then((val){
               imaged[ "${order.orderId}|${product.productId}"]=val;
               if(mounted)
               setState(() {

               });
             });
           }
      setState(() {});
    });
    else
      _loading=false;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(' Current Orders'),
      ),
      body: _loading? Shimmer.fromColors(
          child: Container(
            width: dw(100),
            color: Colors.grey,
            height: dh(100),
          ),
          baseColor: Colors.transparent,
          highlightColor: Colors.white): 
      Container(
        width: dw(100),
        height: dh(90),
        child: ListView.builder(itemBuilder: (context,id){
          return Padding(
            padding: const EdgeInsets.all(16.0),
            child: Container(
              width: 200,
              child: Material(
                  color: Colors.white,
                  elevation: 14.0,
                  borderRadius: BorderRadius.circular(24.0),
                  shadowColor: Color(0x802196F3),
                  child: Container(
                      width: 200,
                      child: Column(
                        children: <Widget>[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(
                                '${current.permUser.totalOrders[id].orderedTime}',
                                  style: TextStyle(
                                      fontSize: 20, fontFamily: 'JosefinSans'),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(15.0),
                                child: Text(
                                  '₹${current.permUser.totalOrders[id].calculteTotal()}',
                                  style: TextStyle(
                                      fontSize: 20, fontFamily: 'JosefinSans'),
                                ),
                              )
                            ],
                          ),
                          Container(
                            width: dw(100),
                            height: dh(30),
                            child: ListView.builder(itemBuilder: (context,jd){
                              return list(id,jd,"${current.permUser.totalOrders[id].orderId}|${current.permUser.totalOrders[id].products[jd].productId}");
                            },itemCount: current.permUser.totalOrders[id].products.length),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(left: 10, top: 10),
                            child: Row(
                              children: <Widget>[
                                Padding(
                                  padding: EdgeInsets.only(top: 10, left: 10),
                                  child: Align(
                                      child: Icon(
                                        Icons.shop_two,
                                        size: 30,
                                        color: Color.fromRGBO(27, 113, 127, 1),
                                      )),
                                ),
                                Padding(
                                  padding: EdgeInsets.only(top: 10, left: 10),
                                  child: Text(
                                    '${current.permUser.totalOrders[id].shop.name}',
                                    style: TextStyle(
                                        fontSize: 20,
                                        fontFamily: 'JosefinSans'),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Column(
                            children: <Widget>[
                              SizedBox(height: 10),
                              Row(
                                children: <Widget>[
                                  Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Icon(
                                      Icons.home,
                                      size: 30,
                                      color: Color.fromRGBO(27, 113, 127, 1),
                                    ),
                                  ),
                                  Expanded(
                                    child: Container(
                                      padding: EdgeInsets.all(10),
                                      child: Text(
                                        '${current.permUser.totalLocations[current.permUser.locationIndex].address}',
                                        style: TextStyle(fontSize: 18, fontFamily: 'JosefinSans'),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              (current.permUser.totalOrders[id].status==2)? Padding(
                                padding: EdgeInsets.only(top: 10, left: 10),
                                child: Text(
                                  'delivered on ${current.permUser.totalOrders[id].deliveredTime}',
                                  style: TextStyle(
                                      fontSize: 20,
                                      fontFamily: 'JosefinSans'),
                                ),
                              ):Container()
                            ],
                          ),
                        ],
                      ))),
            ),
          );
        },itemCount: current.permUser.totalOrders.length,),
      )
    );
  }

//  Widget myDetailsContainer1() {

}
