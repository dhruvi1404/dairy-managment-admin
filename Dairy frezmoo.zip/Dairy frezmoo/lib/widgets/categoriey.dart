import 'package:flutter/material.dart';
import '../screens/brands_screen.dart';
import '../screens/type_of_milk.dart';
class Categories extends StatelessWidget {
//  Widget createCat(String image, String title,double bottom,double left,Function click) {
//    return Expanded(
//        child: InkWell(
//            onTap:click,
//            child: Container(
//                child: Column(children: <Widget>[
//      Stack(children: <Widget>[
//        Container(
//          decoration: BoxDecoration(
//            image: DecorationImage(
//              image: AssetImage(image),
//              fit: BoxFit.fill,
//              colorFilter: ColorFilter.mode(Colors.black45.withOpacity(0.5), BlendMode.darken)
//            ),
//            boxShadow: [
//              BoxShadow(
//                color: Colors.black,
//                blurRadius: 5.0,
//                offset: Offset(4, 4)
//              )
//            ],
//            borderRadius: BorderRadius.circular(10),
//          ),
//          // child:Container(child: ClipRRect(
//          //     borderRadius: BorderRadius.circular(20),
//          //     child: Image(
//          //       image: AssetImage(image),
//          //       fit: BoxFit.fill,
//
//          //     ))),
//          height: 150,
//
//          margin: EdgeInsets.symmetric(horizontal: 10, vertical: 20),
//        ),
//        Positioned(
//            bottom: bottom,
//            left: left,
//            child: Container(
//                width: 220,
//                padding: EdgeInsets.symmetric(vertical: 5, horizontal: 50),
//                child: Text(
//                  title,
//                  style: TextStyle(
//                    fontFamily: 'OpenSans',
//                    fontSize: 26,
//                    color: Colors.white,
//                  ),
//                  softWrap: true,
//                  overflow: TextOverflow.fade,
//                ))),
//      ])
//    ]))));
//  }
  Widget Category(String image,BuildContext context){
    return InkWell(
      onTap:()=>Navigator.of(context).pushNamed(BrandScreen.bransScreen) ,
      child: Container(
        height:100,
        width:MediaQuery.of(context).size.width,

        child: Padding(
          padding: const EdgeInsets.only(left:30,right:30),
          child: Container(
              decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(
                        color: Colors.black,
                        blurRadius: 10,
                        offset: Offset(2,2)
                    ),

                  ],
                  border: Border.all(color:Colors.black),
                  borderRadius: BorderRadius.circular(15)
              ),

              child: ClipRRect(
                  borderRadius: BorderRadius.circular(15),
                  child: Image.asset(image,fit: BoxFit.cover,))),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: <Widget>[
                    Category('assets/images/brand.png',context),
                     SizedBox(height:20),
                    Category('assets/images/types.png',context),
                   SizedBox(height:20),
                  Category('assets/images/vendors.png',context),






      ],
    );
  }
}
